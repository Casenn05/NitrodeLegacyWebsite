<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: /User/Dashboard");
    exit;
}?>

<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode</title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>
<style> 
body {
  background-image: url('/bgu.jpg');
}
</style>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>

<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?>
				<div class="main-content">
                                <center>
                                <div class="card text-white bg-dark mb-3" style="max-width: 50rem;">
  <div class="card-body">

                                <center><img id="MainLogoImage" title="Nitrode" class="center-block img-responsive" src="/stuff/Image/LogoFull.png" " width="500" ></center>
                               <center> <iframe width="560" height="315" src="https://www.youtube.com/embed/hml5yMEZAH4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> </center>
                               <div class="d-grid gap-2">

                                <a href="/register/" class="btn btn-primary btn-primary btn-lg mt-3 mr-2">Click Here To Get Started <i class="fa-solid fa-user-plus"></i></a></center>
                             
                        </div>
                    </div>
                </div>
                        </div>

<div></div><br>
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/ads/ad1.php';
		?>  
        

	<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>