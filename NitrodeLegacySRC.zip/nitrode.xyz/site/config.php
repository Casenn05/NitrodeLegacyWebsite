<?php


define('DB_SERVER', "fdb21.awardspace.net");
define('DB_USERNAME', "3335699_nitrode");
define('DB_PASSWORD', "V:iCOv/p0:XZnl:I");
define('DB_NAME', "3335699_nitrode");
?>