<div class="card border-primary mb-3" style="max-width: 50rem;">
  <div class="card-body">
 <p align='left'><img src="echo "<td>".$row['render2']."</td>"; " alt="" width="50" height="50" class="rounded-circle me-2"> <small><b>echo "<td>".$row['username']."</td>";</b> echo "<td>".$row['ranktag']."</td>";  </small></p>
      <div class="d-grid gap-2">
      <a href="/users/profile.php?id= echo "<td>".$row['id']."</td>";" class="btn btn-primary">View Profile</a>
</div>
</div>