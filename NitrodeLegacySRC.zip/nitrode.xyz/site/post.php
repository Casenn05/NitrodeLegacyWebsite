<div class="card border-primary mb-3" style="max-width: 20rem;">
  <div class="card-body">
Forum Post<br>
<small><small>Created By:</small><br>
  <small><small>Post Created:</small><br>
        <a href="#" class="btn btn-primary">VIEW POST</a>
    </div>