<body class="nitrode-vapor">
		    <div id="app">
		<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
<a class="navbar-brand" href="/">
			<img src="/stuff/Image/Logo.png"width="40" height="40" class="navbar-brandimg d-inline-block mr-2" alt="Nitrode" style="width:auto">
			 Nitrode
		</a>
		   	<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar-collapse" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbar-collapse">
			<ul class="nav navbar-nav mr-auto">
     

<ul class="d-flex">
<ul class="nav navbar-nav my-2 my-log-0">
      <position:relative>
        
        <a class="nav-link
dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true"
aria-expanded="true"><i class="far align-right"></i><small>
 <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b> </small> <i class="fa-solid fa-user"></i> </span></a>

<div class="navbar-dropdown dropdown-menu dropdown-menu-right">



            <a class="dropdown-item" href="/logout"><i class="far align-right"></i>Log Out <i class="fa-solid fa-arrow-right-from-bracket"></i> </a>
         </li> </a></ul></ul> </position:relative> </span> 
							
						

			</div>
</nav>
					</nav>										
	</div>
		</div>
		
 
			
				<p>
			</div>
                      
					</div>
	</div>
</nav>
<?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/banner.php'; ?>