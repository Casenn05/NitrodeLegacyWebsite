<div class="alert alert-dismissible alert-danger">
<center><b>Nitrode Site Will Shut Down On September 23rd We are Going To Restart On Development Your Account Will Be Transfered Over To The New Site Because The New Website Will Use The Same Database Make An Account If You Want One Blog Is Being Revamped And Will Stay Open In The Meantime</b></center> 
</div>

<br>
