 <h1>Create Post</h1>
                            <center>
                            <div class="card border-primary mb-3" style="max-width: 30rem;">
  <div class="card-body">

                           <p align='left'><label>Title</label>
<input type="text" class="form-control" placeholder="Title" id="inputDefault">
 <p align='left'><label>Body</label>
<textarea class="form-control" id="exampleTextarea" rows="3"></textarea>
<br>
<p style="color:red;"><b>Creating A Post That Violates Our Terms Of Service Can Apply Moderation Action On Your Account.</b> </p>
<br>
<center><button type="button" class="btn btn-outline-primary">Create Post <i class="fa-solid fa-plus"></i></button>
</center></center>
</div>