     <ul id="myUL">

 <?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/dbc.php';
$query = $sqlLink->query("SELECT * FROM server ORDER by serverid");

while($row = $query->fetch_array()){      echo "<tr>";
       echo "<td><hr><h3 align='center'>".$row['Servername']."</h3>";
    echo "<td><p align='left'><small>Hoster:<b> ".$row['hoster']."</b></small></p>";
        echo "<td><p align='left'><small>Players: ".$row['playersonline']."</small></p>";
        echo "<small><p align='left'><td>Status: <span class='badge bg-info'>".$row['status']."</small></span></p>";
    echo "  <td><p align='left'><small>Client Version: <span class='badge bg-secondary'>".$row['clientversion'].'</small></span></p><div class="d-grid gap-2">
    <a class="btn btn-lg btn-secondary" href="/games/server.php?serverid='.$row["serverid"].'">View Server  <i class="fa-solid fa-server"></i></a></td><hr></div>';

    
          echo "</tr>" ;}?>
                