
<div class="card border-primary mb-3" style="max-width: 8rem;"><div class="game-card-thumb-container"> <img class="game-card-thumb" src="https://nitrode.xyz/stuff/Image/gameicon.jpeg" width="100" height="100"><hr>Place<br> <small><small>Players: 0<br>By: Test </small></small><span class="badge rounded-pill bg-primary">Client Version</span>
 </span>

