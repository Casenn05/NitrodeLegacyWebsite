Server = game:GetService("NetworkServer")
RunService = game:GetService("RunService")
Server:start(Port, 0)
RunService:run()
function onJoined(newPlayer)
print ("An new connection was accepted.")
newPlayer:LoadCharacter()
while true do 
wait(0.001) 
if newPlayer.Character.Humanoid.Health == 0
then print ("Player died") wait(5) newPlayer:LoadCharacter() print("Player respawned")
elseif newPlayer.Character.Parent == nil then wait(5) newPlayer:LoadCharacter()
end
end
end

game.Players.PlayerAdded:connect(onJoined)