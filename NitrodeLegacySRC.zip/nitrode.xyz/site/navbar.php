
<?php
if(isset($_SESSION['id'])){
    require "config2.php";
}
                        ?>
                   
                        


<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
<a class="navbar-brand" href="/">
			<img src="/stuff/Image/Logo.png"width="40" height="40" class="navbar-brandimg d-inline-block mr-2" alt="Nitrode" style="width:auto">
			 Nitrode
		</a>
		   	<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar-collapse" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="navbar-nav me-auto">
              <li class="nav-item">
          <a class="nav-link" href="/games">Games 
<i class="fa-solid fa-gamepad"></i>
</a>
        </li>
            <li class="nav-item">
          <a class="nav-link" href="/catalog">Catalog <i class="fa-solid fa-bag-shopping"></i> </a>
        </li>
            <li class="nav-item">
          <a class="nav-link" href="/forums">Forums <i class="fa-solid fa-comments"></i> </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/develop">Develop <i class="fa-solid fa-paintbrush"></i> </a>
        </li>
	<li class="nav-item"><a class="nav-link" href="/users/">Users <i class="fa-solid fa-users"></i> </a></li>
           <li class="nav-item">
          <a class="nav-link" href="https://blog.nitrode.xyz/">Blog <i class="fa-solid fa-rss"></i></a></li>
       
   



</ul>
      </ul>


<div class="navbar-button-container">
                    <?php 
                    $db3 = $db;
                    $lid = $_SESSION['id'];
                    $usrquery = $db3->query("SELECT * FROM users WHERE id = '$lid'");
                    $usr = $usrquery->fetch();
                    if(isset($_SESSION['id'])){
                        echo '
                    <div class="navbar-button-container">
                        <a class="btn btn-sm btn-outline-light my-1 mr-2"data-toggle="tooltip" data-html="true"
                           data-placement="bottom" title="'. $usr['TK'] . ' Nitrokens"
                           href="/currency"><img src="/stuff/Image/Icons/nitrokens1.png" width="22" height="22">: '.  $usr['TK']  .'</a>';
                    }?>
                 
</div> 
</div>
    <ul class="nav navbar-nav my-2 my-log-0">
        <a class="nav-link
dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true"
aria-expanded="true"><i class="far align-right"></i><small>
 <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b> </small> <i class="fa-solid fa-user"></i> </span></a>
 <position:relative>
<div class="navbar-dropdown dropdown-menu dropdown-menu-right">
                                  <a class="dropdown-item" href="/User/Settings"><i class="far align-right"></i>Settings <i class="fa-solid fa-gear"></i> </a>
            <a class="dropdown-item" href="/users/profile.php?id=<?php echo ($_SESSION["id"]); ?>"><i class="far align-right"></i>Profile <i class="fa-solid fa-user"></i> </a>
            <a class="dropdown-item" href="/logout"><i class="far align-right"></i>Log Out <i class="fa-solid fa-arrow-right-from-bracket"></i> </a>
      </position:relative>   </li> </a> </span> 
</div>

            
        	</a>

							


			</div>
</nav>
					</nav>										
	</div>
		</div>
			<nav class="navbar navbar-expand-lg navbar-dark navbar-top bg-dark py-0">    <div id="app">
			    <button class="navbar-toggler navbar-toggler-left" type="button" data-toggle="collapse" data-target="#secondaryNavbar" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="secondaryNavbar">
			<div class="container">
			    <nav class="nav nav-underline nav-scroller-inner">
      <ul class="navbar-nav me-auto">
				<a class="nav-link" href="/develop"><li class="far align-middle"></li> <i class="fa-solid fa-plus"></i> Create</a>
				<a class="nav-link" href="/User/Avatar"><li class="far align-middle"></li> <i class="fa-solid fa-user-pen"></i>  Avatar</a>



 </div>
</div>
</nav>
<?php  include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/bannedconnect.php'; ?>
<?php include_once "/site/isbannedinfo.php"; ?>
<?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/banner.php'; ?>
<?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/isbanned.php'; ?>
