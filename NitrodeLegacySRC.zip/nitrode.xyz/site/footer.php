
<footer>
<div class="container text-center py-2">
<center>


    <p></p>


        
       
			
		
	
 <div></div>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>

	
<footer>
<style> .footer  {position: bottom} </style>
<div class="footer">
<hr>
    <p></p>
  <big> </big><center><big><p><b>Nitrode</b> 2022 ©</p> </big> </center>
  <center>
  We are In No Way Affiliated With The ROBLOX Corporation  <p><a href="mailto:nitrode@protonmail.com">Support</a> | <a href="/tos">Terms Of Service</a> | <a href="/privacy">Privacy Policy</a> | <a href="/about">About Us</a></p> <p></p>
<div>

  <center><b>Social</b></center>
<a href="https://youtube.com/channel/UCeX-5D5SHt0SvQ70QRmBt6A">YouTube <i class="fa-brands fa-youtube"></i></a> | <a href="https://twitter.com/nitrodeofficial?s=21">Twitter <i class="fa-brands fa-twitter"></i></a> | <a href="https://discord.gg/qQwGRY6XzW">Discord <i class="fa-brands fa-discord"></i></a> | <a href="https://www.reddit.com/r/Nitrode/">Reddit <i class="fa-brands fa-reddit"></i></a> | <a href="https://www.tiktok.com/@nitroderblx">TikTok <i class="fa-brands fa-tiktok"></i></a>
</div></center></div></div></footer></center>
</div></center></div></div></footer></center></footer>