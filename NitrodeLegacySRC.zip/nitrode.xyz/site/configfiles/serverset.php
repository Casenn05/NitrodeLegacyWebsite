<?php session_start();
include $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/connect2.php';
	if(isset($_SESSION['serverid'])){
		$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
		if ($polaczenie->connect_errno!=0)
		{
			echo "Error: ".$polaczenie->connect_errno;
		}
		else
		{
			
			if ($rezultat = @$polaczenie->query(
			sprintf("SELECT * FROM server WHERE user='%s'",
			mysqli_real_escape_string($polaczenie,$login))))
			{
					
				$ilu_userow = $rezultat->num_rows;
				if($ilu_userow>0)
				{
					$server = $rezultat->fetch_assoc();
					
					//	$_SESSION['zalogowany'] = true;
					$_SESSION['serverid'] = $server['serverid'];
					$_SESSION['Port'] = $server['Port'];
                                        						$_SESSION['id'] = $server['id'];			
					unset($_SESSION['blad']);
					$rezultat->free_result();
					
				} else {
					
					
				}
				
			}
			
			$polaczenie->close();
		}
	
	}
?>