 <?php

//Create Connnection
$sqlLink = mysqli_connect('fdb21.awardspace.net', '3335699_nitrode', 'V:iCOv/p0:XZnl:I', '3335699_nitrode');

//If Error Connecting
if(!$sqlLink) {
    die('<center><br><h3>Error connecting to servers Database.');
}

?>