<?php
	session_start();
include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/connect2.php';
	if(isset($_SESSION['id'])){
		$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
		if ($polaczenie->connect_errno!=0)
		{
			echo "Error: ".$polaczenie->connect_errno;
		}
		else
		{
			$login = $_SESSION['id'];
			
			if ($rezultat = @$polaczenie->query(
			sprintf("SELECT * FROM asset WHERE user='%s'",
			mysqli_real_escape_string($polaczenie,$login))))
			{
					
				$ilu_userow = $rezultat->num_rows;
				if($ilu_userow>0)
				{
					$wiersz = $rezultat->fetch_assoc();
					
					//	$_SESSION['zalogowany'] = true;
					$_SESSION['id'] = $wiersz['id'];
					$_SESSION['asset'] = $wiersz['asset'];
                                        				
					unset($_SESSION['blad']);
					$rezultat->free_result();
					
				} else {
					
					
				}
				
			}
			
			$polaczenie->close();
		}
	
	}
?>