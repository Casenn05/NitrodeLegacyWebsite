<?php
	session_start();
              include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/bannedconnect.php'; 
	if(isset($_SESSION['id'])){
		$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
		if ($polaczenie->connect_errno!=0)
		{
			echo "Error: ".$polaczenie->connect_errno;
		}
		else
		{
			$login = $_SESSION['username'];
			//if ($_SESSION['username'] == 'CircleLoop') {
			//    header("Location: 403");
			//}
			if ($rezultat = @$polaczenie->query(
			sprintf("SELECT * FROM users WHERE user='%s'",
			mysqli_real_escape_string($polaczenie,$login))))
			{
					
				$ilu_userow = $rezultat->num_rows;
				if($ilu_userow>0)
				{
					$wiersz = $rezultat->fetch_assoc();
					
					//	$_SESSION['zalogowany'] = true;
					$_SESSION['id'] = $wiersz['id'];
					$_SESSION['username'] = $wiersz['username'];
					$_SESSION['TK'] = $wiersz['TK'];
					$_SESSION['blurb'] = $wiersz['blurb'];
					$_SESSION['created_at'] = $wiersz['created_at'];
					unset($_SESSION['blad']);
					$rezultat->free_result();
					
				} else {
					
					
				}
				
			}
			
			$polaczenie->close();
		}
		$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

if ($_SESSION['banned'] == 'yes') {
if (strpos($url,'banned') !== false) {
    
} else {
    header('Location: banned');
}
}
		/*if((count($_SESSION['banned'] == 'yes') && ($_SERVER['PHP_SELF'] != "banned.php"))) {
			header('Location: banned.php');
		}
	if ($_SESSION['banned'] == 'yes' && ($_SERVER['PHP_SELF'] != "banned")) {
		    header('Location: banned');
		}*/
	}
?>