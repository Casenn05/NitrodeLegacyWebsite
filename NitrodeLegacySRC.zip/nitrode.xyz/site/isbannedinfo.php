<?php 	

			if ($rezultat = @$polaczenie->query(
			sprintf("SELECT * FROM users WHERE user='%s'",
			mysqli_real_escape_string($polaczenie,$login))))
			{
					
				$ilu_userow = $rezultat->num_rows;
				if($ilu_userow>0)
				{
					$user = $rezultat->fetch_assoc();
					
					//	$_SESSION['zalogowany'] = true;
					
                                                                $isbanned = $user['isbanned'];
					unset($_SESSION['blad']);
					$rezultat->free_result();
					
				} else {
					
					
				}
				
			}
			
			$polaczenie->close();
		}
		
	}
?>