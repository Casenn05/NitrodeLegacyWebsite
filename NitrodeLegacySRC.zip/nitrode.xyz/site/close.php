<?php
	if (isset($dbcon)) {
		$dbcon = null;
	}
?>