<?php include_once "/site/isbannedinfo.php"; ?>
  <?php
            $bannedid=69420;
            $user="";$about="";$aeae="";$onn="";$kkz="";
            if(!isset($_GET['id'])){
                if(isset($_SESSION['id'])){$bannedid=$_SESSION['id'];}else{
                    header('Location: 404.php');
                }
            }else{$bannedid=$_GET['id'];}

            $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
            if ($polaczenie->connect_errno!=0)
            {
            }
            else
            {
                if ($rezultat = @$polaczenie->query(
                sprintf("SELECT * FROM users WHERE id='%s'",
                mysqli_real_escape_string($polaczenie,$bannedid))))
                {
                        
                    $ilu_userow = $rezultat->num_rows;
                    if($ilu_userow>0)
                    {
                        $user = $rezultat->fetch_assoc();
                        
                        //	$_SESSION['zalogowany'] = true;
                        $username = $wiersz['username'];
                        $joindate = $wiersz['created_at'];
                                                $charapp = $wiersz['charapp'];
                                                $publicban = $wiersz['publicban'];
                                                                                                $ranktag = $wiersz['ranktag'];
                            $aeae = date("F jS Y", strtotime($joindate));
                        $about = $wiersz['blurb'];
                                                $rank = $wiersz['rank'];
                                                                                                $userfriends = $wiersz['userfriends'];
                                                                                                $status = $wiersz['status'];


                                                $TK = $wiersz['TK'];
                      
                        $rezultat->free_result();  
                        
                    } else {
                        //header('Location: 404.php');
                      
         die();
                    }
                    
                 }
            
                $polaczenie->close();
            }
	/*if(isset($_SESSION['id']) && !($bannedid == $_SESSION['id'])){
		$conn = new mysqli($host, $db_user, $db_password);
		$conn->select_db($db_name);
		$sql = "UPDATE `users` SET `views` = '".($kkz+1)."' WHERE `users`.`id` = ".$bannedid.";";
		$result = $conn->query($sql);
		$conn->close();
	}*/
	
	
        ?>
        
        
        <?php if ($user['isbanned'] == '1'){
echo ' <meta http-equiv="refresh" content="0; URL=/banned" />
';}?>

<?php if ($user['isbanned'] == '1'){
    header("location: /banned");
    exit;
}?>