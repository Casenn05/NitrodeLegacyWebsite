</p>
<center>[  <?php echo $wiersz['status']; ?>  ]</center>