<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="/"> <img src="/stuff/Image/Logo.png" width="40" height="40" alt="Nitrode" class="navbar-brandimg d-inline-block mr-2" style="width: auto;"> Nitrode</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar-collapse" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="/forums">Forums <i class="fa-solid fa-comments"></i></a>
        </li>
        <li class="nav-item"><a class="nav-link" href="/users/">Users <i class="fa-solid fa-users"></i> </a></li>
        <li class="nav-item">
          <a class="nav-link" href="https://blog.nitrode.xyz">Blog <i class="fa-solid fa-rss"></i></a>
        </li>
    </ul>
      </ul>
      <div class="text-end">
      <a href="/login" class="btn btn-success">Log In <i class="fa-solid fa-arrow-right-to-bracket"></i></a> 
          <a href="/register" class="btn btn-secondary">Register <i class="fa-solid fa-user-plus"></i></a> 

    </div>
  </div>
</nav>
  
<?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/banner.php'; ?>