<center><small>Logged In As <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b></small></center>


  
     

<div class="card border-primary mb-3" id="MyPlaces">
					<h4 style="margin:0 0 2px">My Places</h4>
					<p class="muted" style="margin:0;">Places Are Not Released Yet</p>				</div>
