<?php
if(isset($_SESSION['id'])){
    require "config2.php";
}
                        ?>
<?php $db3 = $db; $lid = $_SESSION['id']; $usrquery = $db3->query("SELECT * FROM users WHERE id = '$lid'"); $usr = $usrquery->fetch(); { echo ''.  $usr['avatar']  .'';}?>