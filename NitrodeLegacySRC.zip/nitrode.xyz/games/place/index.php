<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Place   </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>
	</head>
  
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';
		?>
				<div class="main-content">
                                <div class="home-header"><div class="app container nav-content">
                                <div class="col" style="max-width: 58rem">
<h2 class="font-weight-normal">Place</h2>
		<div class="row">
			<div class="col-sm-8">
                        <img src="/stuff/baseplate.PNG" class="img-fluid">
                        <p class="mb-0 mt-1"></p>
                        <p>Des</p></div>
                        <div class="col-sm-4">
				<div class="row mx-0 mb-3 pb-2 divider-bottom">
					<div class="pl-3">
                                        					<div class="pl-2">
						<h5 class="font-weight-normal mb-0">Creator:<b> Test</b></h5>
                                                					</div>
                                                                                        <div class="d-grid gap-2">
<br>
  <button class="btn btn-lg btn-success" type="button" style="max-width: 13rem">Play <i class="fa-solid fa-play"></i></button>
</div>
<br>Created:<b> N/aN</b>
<br>Version:<b> N/aN</b>
<br>Visits:<b> N/aN</b>
<br>Players:<b> N/aN</b>
<hr>
Gear Types:<b> N/aN</b></div></div></div></div>
<hr>
<big>Game Servers</big>
<hr>



                                        </div></div></div>
                        </div>
                                <div></div></div></div></div></div>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>

	</footer>
<footer>
<style> .footer  {position: bottom} </style>
  
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>