<title>Nitrode Game Servers | Redict</title>
<meta http-equiv="refresh" content="0; url=/games/selfhost.php" />
