<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Nitrokens   </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>
	</head>

<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';
		?>

				<div class="main-content">
                                <center>
                                 <div class="card border-primary mb-3" style="max-width: 50rem;">
                                   <div class="card-header">Nitrokens</div>

                                   <div class="card-body">


                                 <?php 
                    $db3 = $db;
                    $lid = $_SESSION['id'];
                    $usrquery = $db3->query("SELECT * FROM users WHERE id = '$lid'");
                    $usr = $usrquery->fetch();
                    if(isset($_SESSION['id'])){
                        echo '
                        <center> You Currently Have
                        <a class="data-html="true"
                           data-placement="bottom" title="'. $usr['TK'] . ' Nitrokens"><img src="/stuff/Image/Icons/nitrokens1.png" width="22" height="22">: '.  $usr['TK']  .'$</a>';
                    }?> Nitrokens </p>
                    Nitrokens Is Like Tickets</p>
                    You Get Nitrokens By Daily Rewards And You Can Use Your Nitrokens For Stuff On The Catalog</p>
                    There Will Never Be A Way To Purchase Nitrokens 
                    </p><b><small>Selling Nitrokens Is Bannable And Also Please Do Not Buy Nitrokens By Anybody Who Says They Will Sell Them If You Purchased Nitrokens From A Third Party Source You Have Been Scammed</small></b></center>
                                </div>
                                
       
			</div>
		</div>
	</div>
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>