--rbxsig%IihFx7HdQKuvjF7JoDsD+H53Qw8iz8inuPloxE2NMJhBLUHK3R9BzrLDrCF8szNY+2Bi8xUDmCzPOdShJkPqPSz38OhZIIAc0rtK8xIIbb4A4ynf3t2N4Ho1NOXC490r7vOSS18c49Mb6Eacg/Uvdvjl7JSrf9218gH7FHQgDYI=%
local ServerPort = 53640

local deathSounds = {
	"http://api.nitrode.xyz/asset/death/id/reset"
}

local function Destroy(instance)
    game:GetService("Debris"):AddItem(instance, 0)
end

local NetworkServer = game:GetService("NetworkServer")
NetworkServer:Start(ServerPort)

local RunService = game:GetService("RunService")
RunService:Run()

local Players = game:GetService("Players")
Players.PlayerAdded:connect(function(Player)
    wait()

    Player.CharacterAdded:connect(function(Character)
        local Humanoid = Character:FindFirstChild("Humanoid")
        Humanoid.Died:connect(function()
            wait(5)
            Player:LoadCharacter()
        end)
    end)
	
	Player.Chatted:connect(function(Message)
        local commands = {
            ["ec"] = true,
            ["lollolman"] = true,
            ["cukesim"] = true,
            ["cucksim"] = true,
            ["casenn"] = true,
            ["casenn05"] = true,
            ["reset"] = true,
            ["kys"] = true,
            ["xlxi"] = true,
            ["redman"] = true,
            ["yomi"] = true, 
            ["fortnite"] = true,
            ["epiculy"] = true,
            ["spacebuilder"] = true,
            ["brickluke"] = true,
            ["kyle"] = true,    
            ["sleep"] = true,
            ["flanger"] = true,
            ["speakerpro2"] = true,
            ["peis"] = true,
            ["lisagaming"] = true,
            ["cocomelon"] = true, 
            ["massachusetts"] = true,
            ["brent"] = true,
            ["egg"] = false,
            ["pog"] = false,
            ["poggers"] = false
        }

        if commands[Message:sub(2):lower()] == 1 or commands[Message:lower()] == 2 then
            if Player.Character then
				local Head = Player.Character:FindFirstChild("Head")
				if Head then
					local Sound = Instance.new("Sound", Head)
					Sound.SoundId = deathSounds[math.random(1,#deathSounds)]
					Sound:Play()
				end
				
                Player.Character:BreakJoints()
            end
        end
    end)
end)

NetworkServer.ChildAdded:connect(function(child)
    child.Name = "Connection"
end)