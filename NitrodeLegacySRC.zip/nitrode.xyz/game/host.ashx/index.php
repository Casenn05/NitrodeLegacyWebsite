<?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/serverset.php';?>
<?php
            $hostingtoken=69420;
            $user="";$about="";$aeae="";$onn="";$kkz="";
            if(!isset($_GET['hostingtoken'])){
                if(isset($_SESSION['hostingtoken'])){$id=$_SESSION['hostingtoken'];}else{
                    header('Location: 404.php');
                }
            }else{$hostingtoken=$_GET['hostingtoken'];}

            $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
            if ($polaczenie->connect_errno!=0)
            {
            }
            else
            {
                if ($rezultat = @$polaczenie->query(
                sprintf("SELECT * FROM server WHERE hostingtoken='%s'",
                mysqli_real_escape_string($polaczenie,$hostingtoken))))
                {
                        
                    $ilu_userow = $rezultat->num_rows;
                    if($ilu_userow>0)
                    {
                        $server = $rezultat->fetch_assoc();
                        
                        //	$_SESSION['zalogowany'] = true;
                        $hostingtoken = $server['hostingtoken'];
                        
                      
                        $rezultat->free_result();  
                        
                    } else {
                        //header('Location: 404.php');
                      
         die();
                    }
                    
                 }
            
                $polaczenie->close();
            }
	/*if(isset($_SESSION['hostingtoken']) && !($hostingtoken == $_SESSION['hostingtoken'])){
		$conn = new mysqli($host, $db_user, $db_password);
		$conn->select_db($db_name);
		$sql = "UPDATE `users` SET `views` = '".($kkz+1)."' WHERE `users`.`hostingtoken` = ".$hostingtoken.";";
		$result = $conn->query($sql);
		$conn->close();
	}*/
	
	
        ?>
Port = <?php echo $server['Port']; ?>

<?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/host.lua';?>
                