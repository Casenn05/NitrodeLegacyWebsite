dofile("http://api.nitrode.xyz/asset/scripts/StarterScript.lua")

showServerNotifications = true

local playername = "Player" 
local playerid = "1" 
local playercharacter = "http://nitrode.xyz/Asset/CharacterFetch.ashx/?id=1" 


player = game:GetService("Players"):CreateLocalPlayer(0)
player.Name = playername 
player.userId = playerid 
player.CharacterAppearance= playercharacter 
game:GetService("Visit")
game:GetService("RunService"):run()
player:LoadCharacter()
print ("Play in the old studio with this.")
while true do wait(0.001)
if player.Character.Humanoid.Health == 0
then wait(5) player:LoadCharacter()
print ("LocalPlayer was killed.")
end
end