<?php
// Initialize the session
session_start();
header("content-type:text/plain");
?>
 <?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/serverset.php';?>
<?php
            $serverid=69420;
            $user="";$about="";$aeae="";$onn="";$kkz="";
            if(!isset($_GET['serverid'])){
                if(isset($_SESSION['serverid'])){$id=$_SESSION['serverid'];}else{
                    header('Location: 404.php');
                }
            }else{$serverid=$_GET['serverid'];}

            $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
            if ($polaczenie->connect_errno!=0)
            {
            }
            else
            {
                if ($rezultat = @$polaczenie->query(
                sprintf("SELECT * FROM server WHERE serverid='%s'",
                mysqli_real_escape_string($polaczenie,$serverid))))
                {
                        
                    $ilu_userow = $rezultat->num_rows;
                    if($ilu_userow>0)
                    {
                        $server = $rezultat->fetch_assoc();
                        
                        //	$_SESSION['zalogowany'] = true;
                        $serverid = $server['serverid'];
                        
                      
                        $rezultat->free_result();  
                        
                    } else {
                        //header('Location: 404.php');
                      
         die();
                    }
                    
                 }
            
                $polaczenie->close();
            }
	/*if(isset($_SESSION['serverid']) && !($id == $_SESSION['serverid'])){
		$conn = new mysqli($host, $db_user, $db_password);
		$conn->select_db($db_name);
		$sql = "UPDATE `users` SET `views` = '".($kkz+1)."' WHERE `users`.`serverid` = ".$serverid.";";
		$result = $conn->query($sql);
		$conn->close();
	}*/
	
	
        ?>
dofile("http://api.nitrode.xyz/asset/scripts/StarterScript.lua")

showServerNotifications = true

local server = "<?php echo $server['IP']; ?>"
local serverport = <?php echo $server['Port']; ?>

local clientport = 0
local playername = "<?php echo htmlspecialchars($_SESSION["username"]); ?>" 
local playerid = "<?php echo htmlspecialchars($_SESSION["id"]); ?>" 
local playercharacter = "http://nitrode.xyz/Asset/CharacterFetch.ashx/?id=<?php echo htmlspecialchars($_SESSION["id"]); ?>"
 
 
game:SetMessage("Connecting to server...") 
function dieerror(errmsg) 
game:SetMessage(errmsg) 
wait(math.huge) 
end 
local suc, err = pcall(function()
client = game:GetService("NetworkClient")
player = game:GetService("Players"):CreateLocalPlayer(0)
player:SetSuperSafeChat(false)
pcall(function() game:GetService("Players"):SetChatStyle(Enum.ChatStyle.ClassicAndBubble) end) 
game:GetService("Visit")
player.Name = playername 
player.userId = playerid 
player.CharacterAppearance= playercharacter 
game:ClearMessage() 
end) 
if not suc then 
dieerror(err) 
end 
function connected(url, replicator) 
local suc, err = pcall(function() 
local marker = replicator:SendMarker() 
end) 
if not suc then 
dieerror(err) 
end 
marker.Recieved:wait() 
local suc, err = pcall(function() 
game:ClearMessage() 
end) 
if not suc then 
dieerror(err) 
end 
end 
function rejected() 
dieerror("Connection failed: Rejected by server.") 
end 
function failed(peer, errcode, why) 
dieerror("Failed [".. peer.. "], ".. errcode.. ": ".. why) 
end 
local suc, err = pcall(function() 
client.ConnectionAccepted:connect(connected) 
client.ConnectionRejected:connect(rejected) 
client.ConnectionFailed:connect(failed) 
client:Connect(server, serverport, clientport, 20) 
end) 
if not suc then 
local x = Instance.new("Message") 
x.Text = err 
x.Parent = workspace 
wait(math.huge) 
end 
while true do 
wait(0.001) 
replicator:SendMarker() 
end  