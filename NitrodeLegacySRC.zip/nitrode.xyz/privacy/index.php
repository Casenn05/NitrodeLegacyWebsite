<?php
// Initialize the session
session_start();
?>
<!DOCTYPE html>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Privacy </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">
							                <script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>
                                                        <style>
                                                    
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>
	</head>
	<body>
	
	<div class="container text-center">
								
					</div>





</style>
</head>
<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?>
						</div>
				<div class="main-content">
<p>
<center>
<div class="card border-primary mb-3" style="max-width: 40rem;">
  <div class="card-header">Nitrode Privacy Policy</div>
  <div class="card-body">
 <p align="left">1. We Use Cloudflare <b>Everything You Do On Nitrode Goes Through To Them.</b></p>

<p align="left">2. Your Passwords Are Hashed <b>Never Plaintext</b></p>

<p align="left">3. Your IP Can Be Put at Risk By The Game Hoster So <b>We Would Advise You By Joining Self Hosted Servers Is To Use A VPN (and For Game Hosters To Host Your Game Using A Portforwarding supported VPN or Host Your Game With Something Like Playit.gg)</b> </p>

<p align="left">4. Your IP Address Is Collected <b>When You Login</b></p> 


</center>
</div>



				    </div>
</p>

	    
	</p><p></p>
        <footer>
<style> .footer  {position: bottom} </style>
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>



  </div>
	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;

			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

			ga('create', 'UA-110480271-1', 'auto');
			ga('send', 'pageview');
			
			try { (adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
			try { (adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}

					</script>
 
							
	
