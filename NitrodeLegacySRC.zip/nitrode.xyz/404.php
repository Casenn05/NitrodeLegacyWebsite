<?php
// Initialize the session
session_start();
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Error </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                                <script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>
								<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>												<link rel="stylesheet" href="/stuff/css/bootstrap.css">
							<!-- this must load before anything else -->
				<script src="/stuff/Js/manifest.js"></script>
		<script src="/stuff/Js/settings.js"></script>
			<style>
		nav.mb-3 {
			margin-bottom: 0rem !important;
		}
		.alert-padding {
			display: none;
		}
		.alert {
			margin-bottom: 0;
		}
		body {		
			min-width: 250px;
			min-height: 600px;
		}
	
		.main-content > .container {
			display: flex;
			flex-direction: column;
			align-self: center;
		}
			</style>
	</head>
		<body>
		
						
					</div>
	</div>
</nav>
				<div class="main-content">	
                                <body>
		<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?><div class="container">
		<p></p>
		    <p></p>
		    <center><div class="card border-primary mb-3" style="max-width: 30rem;">
  <div class="card-header">Error</div>
  <div class="card-body">
    <h4 class="card-title">404</h4>
    <img src="/stuff/Image/Icons/warning.png" alt="error  width=" 80"="" height="90">
    <p class="card-text">The Page You Were Looking For Does Not Exist</p>
    <a href="/" class="btn btn-danger btn-lg mt-3 mr-2">Go Home</a>
     <a href="" class="btn btn-outline-danger btn-lg mt-3 mr-2">Retry</a>
  </div>
 </center>

	</a>
			</div>
		</div>
	</div>
 <div></div>

	
  </div>
</div>
  </div>
 
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>