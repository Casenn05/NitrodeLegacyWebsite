<?php include_once $_SERVER['DOCUMENT_ROOT'].'/stuff/host.php';?>  </div>
