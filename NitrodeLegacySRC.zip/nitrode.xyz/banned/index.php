<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/bannedinfoupadate.php';?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Banned   </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>
	</head>

<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarbanned.php'; 
		?>
            
				<div class="main-content">
                                  <?php
                $id=69420;
            $user="";$about="";$aeae="";$onn="";$kkz="";
            if(!isset($_GET['id'])){
                if(isset($_SESSION['id'])){$id=$_SESSION['id'];}else{
                    header('Location: /404');
                }
            }else{$id=$_GET['id'];}

            $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
            if ($polaczenie->connect_errno!=0)
            {
                echo "Error: ".$polaczenie->connect_errno;
            }
            else
            {
                if ($rezultat = @$polaczenie->query(
                sprintf("SELECT * FROM users WHERE id='%s'",
                mysqli_real_escape_string($polaczenie,$id))))
                {
                        
                    $ilu_userow = $rezultat->num_rows;
                    if($ilu_userow>0)
                    {
                        $wiersz = $rezultat->fetch_assoc();
                        
                        //	$_SESSION['zalogowany'] = true;
                        $banreason = $wiersz['banreason'];
                                                $banneduntil = $wiersz['banneduntil'];
                                                                                                $bannedreview = $wiersz['bannedreview'];
                        unset($_SESSION['blad']);
                        $rezultat->free_result();        $polaczenie->close(); 
                    }
                    
                }
                
            }  
            ?>
           
                    <?php if ($wiersz['isbanned'] == '0'){
echo ' <meta http-equiv="refresh" content="0; URL=/" />
';}?>
 <?php if ($wiersz['isbanned'] == '0'){
    header("location: /User/Dashboard");
    exit;
}?>

                                <center>
<div class="card border-primary mb-3" style="max-width: 40rem;">
  <div class="card-header">Nitrode Moderation</div>
  <div class="card-body">
    <h4 class="card-title">Banned From Nitrode</h4>
    <p align="left">Our Moderation Team Has Detected You Have Violated Nitrodes Terms of Service</p>
    <p align="left"><b>Reason</b>: <code style="word-wrap: break-word;white-space: pre-line;"><?php echo $banreason; ?></code> </p>
         <p align="left"><b>Reviewed</b>: <?php echo $bannedreview; ?> </p>
     <p align="left"><b>Banned Until</b>: <?php echo $banneduntil; ?> </p>
<small>Using An Alt Account To Bypass A Ban Will Make Your Account Not Appealable And Risk of Alt Also Getting Banned.</small> 
    
  </div>


</div>
          <p></p>
          

 
</div>

    </p>
</body>
</html>
        
       
			</div>
		</div>
	</div>
 <div></div>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>


