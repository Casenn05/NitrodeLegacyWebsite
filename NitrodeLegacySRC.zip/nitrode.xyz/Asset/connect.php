<?php
$host = "fdb21.awardspace.net";
$db_user = "3335699_nitrode";
$db_password = "V:iCOv/p0:XZnl:I";
$db_name = "3335699_nitrode";
?>