<?php header("Content-type: text/plain") ;?>
<?php include_once $_SERVER['DOCUMENT_ROOT'].'/Asset/CharacterFetch.ashx/char2.php';?>