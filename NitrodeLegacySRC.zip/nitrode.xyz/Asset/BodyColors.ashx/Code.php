<?php include_once $_SERVER['DOCUMENT_ROOT'].'/Asset/BodyColors.ashx/bodystuff.php';?><<?php echo $wiersz['xml']; ?>xml version="1.0" encoding="utf-8" standalone="yes"<?php echo $wiersz['xml']; ?>>
<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
<External>null</External>
<External>nil</External>
<Item class="BodyColors">
<Properties>
<int name="HeadColor"><?php echo $wiersz['headcolor']; ?></int>
<int name="LeftArmColor"><?php echo $wiersz['leftarmcolor']; ?></int>
<int name="LeftLegColor"><?php echo $wiersz['leftlegcolor']; ?></int>
<string name="Name">Body Colors</string>
<int name="RightArmColor"><?php echo $wiersz['rightarmcolor']; ?></int>
<int name="RightLegColor"><?php echo $wiersz['rightlegcolor']; ?></int>
<int name="TorsoColor"><?php echo $wiersz['torsocolor']; ?></int>
<bool name="archivable">true</bool>
</Properties>
</Item>
</roblox>