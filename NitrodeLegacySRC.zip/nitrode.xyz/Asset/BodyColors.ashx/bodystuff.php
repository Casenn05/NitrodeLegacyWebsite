<?php
// Initialize the session
session_start();
?><?php include_once "infoupdate.php"; ?><?php
            $id=69420;
            $user="";$about="";$aeae="";$onn="";$kkz="";
            if(!isset($_GET['id'])){
                if(isset($_SESSION['id'])){$id=$_SESSION['id'];}else{
                    header('Location: 404.php');
                }
            }else{$id=$_GET['id'];}

            $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
            if ($polaczenie->connect_errno!=0)
            {
            }
            else
            {
                if ($rezultat = @$polaczenie->query(
                sprintf("SELECT * FROM users WHERE id='%s'",
                mysqli_real_escape_string($polaczenie,$id))))
                {
                        
                    $ilu_userow = $rezultat->num_rows;
                    if($ilu_userow>0)
                    {
                        $wiersz = $rezultat->fetch_assoc();
                        
                        //	$_SESSION['zalogowany'] = true;
                        $username = $wiersz['username'];
                        $joindate = $wiersz['created_at'];
                                                $bodycolors = $wiersz['bodycolors'];
                                                $publicban = $wiersz['publicban'];
                            $aeae = date("F jS Y", strtotime($joindate));
                        $about = $wiersz['blurb'];
                                                $rank = $wiersz['rank'];

                                                $TK = $wiersz['TK'];
                      
                        $rezultat->free_result();  
                        
                    } else {
                        //header('Location: 404.php');
                      
         die();
                    }
                    
                 }
            
                $polaczenie->close();
            }
	/*if(isset($_SESSION['id']) && !($id == $_SESSION['id'])){
		$conn = new mysqli($host, $db_user, $db_password);
		$conn->select_db($db_name);
		$sql = "UPDATE `users` SET `views` = '".($kkz+1)."' WHERE `users`.`id` = ".$id.";";
		$result = $conn->query($sql);
		$conn->close();}*/?>