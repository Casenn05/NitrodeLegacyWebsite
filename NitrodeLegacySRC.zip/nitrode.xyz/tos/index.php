<?php
// Initialize the session
session_start();
?>
<!DOCTYPE html>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Terms of Service </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">
							                <script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>
                                                        <style>
                                                    
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>
	</head>
	<body>
	
	<div class="container text-center">
								
					</div>





</style>
</head>
<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?>
						</div>
  
				<div class="main-content">
<p>
<center>
<div class="card border-primary mb-3" style="max-width: 40rem;">
  <div class="card-header">Nitrode Terms Of Service</div>
  <div class="card-body">
 <p align="left">1. You Must Be At Least The Age Of 13 And Older To Use Nitrode</p>

<p align="left">2. NSFW Content Is Prohibited on Nitrode</p>

<p align="left">3. You May Use Profanity But Using Slurs are Prohibited On Nitrode </p>

<p align="left">4. Do Not Be Toxic or Bully or Slander People on Nitrode</p> 

<p align="left">5. Doxxing People Is Prohibited Even Offsite  people who dox are not welcome on Nitrode. </p>

<p align="left">6. Do Not Make More Than 3 alt accounts  Alt accounts are allowed but only a reasonable amount.</p>

<p align="left">7. Do Not Post anything Malicious</p>

<p align="left">8. Creating or Talking about drama is prohibited on Nitrode </p>

<p align="left">9. You May be Held Liable For who you Invite to Nitrode Breaks the Rules (It Depends on Which Offense They Break.) </p>

<p align="left">10. Exploiting Is Prohibited On Nitrode</p>

<p align="left">11. Ban Evasion is Not Allowed on Nitrode</p>

<p align="left">12. Post Farming and Currency Farming is Not Allowed on Nitrode</p>

<p align="left">13.  Racist or Nazi or Facist Behavior Is Not Allowed On Nitrode </p>
</center>
</div>


				    </div>
</p>

	    
	</p><p></p>

<footer>
<style> .footer  {position: bottom} </style>
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>

  </div>
	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;

			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

			ga('create', 'UA-110480271-1', 'auto');
			ga('send', 'pageview');
			
			try { (adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
			try { (adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}

					</script>
 
							
	
