<title>Nitrode | Report Abuse</title>
 <h1>Report User</h1>
         <input type="text" name="username" placeholder="Username">
<br><br>
 <label for="reason">Reason:</label>
  <select name="reason" id="reason">
    <option value="slurs">Using Slurs</option>
    <option value="Explioting">Explioting</option>
    <option value="Stolen">Stolen Account</option>
    <option value="Selling">Selling Nitrokens</option>
        <option value="Bullying">Bullying</option>
                <option value="Toxic">Toxic Behavior</option>
                                <option value="racist">Racist Behavior</option>
                                                <option value="bad">Homophobic/Transphobic Behavior</option>
        <option value="Other">Other</option>
  </select><br><br>
  <textarea id="otherreason" name="otherreason" rows="4" cols="50">

</textarea>
<br><br><center>
  <input type="submit" value="Submit"></center>
