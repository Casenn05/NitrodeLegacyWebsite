<?php

if (isset($_POST['submit']) && $_POST['g-recaptcha-response'] != "") {
  include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/db.php';
    $secret = '6LdZGcQgAAAAAEh1dExCnpQ9Iw6HNJy1OVFmMfOp';
    $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret . '&response=' . $_POST['g-recaptcha-response']);
    $responseData = json_decode($verifyResponse);
    if ($responseData->success) {
        
    }
}