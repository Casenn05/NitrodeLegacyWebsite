<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: /User/Dashboard");
    exit;
}?>

<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Register </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>


						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>

<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?>
				<div class="main-content">
                                </div>
                                <br>
                                <center>
                                <div class="card border-primary mb-3" style="max-width: 30rem;">
  <div class="card-header">Register</div>
  <div class="card-body">
  <?php

include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/db.php';
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Usernames can only contain letters, numbers, and underscores.";
    } else{
        $sql = "SELECT id FROM users WHERE username = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = trim($_POST["username"]);
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username has already been taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); 
            if(mysqli_stmt_execute($stmt)){
        $stmt = "Account Successfully Created Please Log In";
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
 
<!DOCTYPE html>
<html lang="en">
<body>
    <div class="wrapper">
    
     
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        
        <?php 
        if(($stmt)){
            echo '<div class="alert alert-success">' . $stmt . '</div>';
        }        
        ?>
            <div class="form-group">
                                     

            <label></label>
                <input type="text" name="username" placeholder="Username" class="form-control  <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span><br>
            <div class="form-group"> 
            <label></label>
                <input type="password" name="password" placeholder="Password" class="form-control  <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
 <span class="invalid-feedback"><?php echo $password_err; ?></span><br>

            <div class="form-group">
            <label></label>
                <input type="password" placeholder="Comfirm Password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
 <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
  <div class="form-group">
            <br>
               <form action="validate-captcha.php" method="post">
                                            <div class="g-recaptcha" data-sitekey="6LdZGcQgAAAAAFYT36Tb0mRvKEogOOgzJoohhIb1"></div>

            
 </p>
                </div>
 		          
                </p>


 <center>               <div class="form-group">  <button type="submit" name="sm" class="btn  btn-success"> Register <i class="fa-solid fa-user-plus"></i></button>    <a href="/login/" class="btn btn-primary btn-primary btn"> Log In <i class="fa-solid fa-arrow-right-to-bracket"></i></a>   
 </div> 
 
</div>


  </div></center>
                               
                        </div>
                    </div>
                </div>
                        </div>

<div></div>
<br>
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/ads/ad1.php';
		?>  
        


	<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>