<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: /User/Dashboard");
    exit;
}
 
// Include config file
include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/db.php';
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["TK"] = $TK;
                               $_SESSION["rank"] = $rank;
                            $_SESSION["username"] = $username;        
                            $_SESSION["created_at"] = $created_at;   
                            $_SESSION["banreason"] = $reason;
                            $_SESSION["isbanned"] = $isbanned;
                                                        $_SESSION["charapp"] = $charapp;

                            
                            // Redirect user to welcome page
                            header("location: /User/Dashboard");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 <script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>
 <script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nitrode | Log In</title>
    <link rel="stylesheet" href="/stuff/css/bootstrap.css">
    <style>
    
						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>
    
    </style>
</head>

<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?>
<body>


<br>
<center>
<div class="card border-primary mb-3" style="max-width: 30rem;">
     <div class="card-header">Log In</div>
		  <div class="card-body">


</p>



        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>   <br> 
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group d-grid gap-2">
            </p>
                <button type="submit" class="btn btn-secondary">Log In <i class="fa-solid fa-arrow-right-to-bracket"></i></button>
            </div>
            <br>
            <a href="/register">Dont Have An Account Click Here To Create One</a>
            </p>
        </form>
        </center>
    </div>
    <br>

<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/ads/ad1.php';
		?>  
        
</body>
</html>
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>