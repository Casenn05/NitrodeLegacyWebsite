<?php
if(!empty($_GET['id'])){
    $host     = 'fdb21.awardspace.net';
    $username = '3335699_nitrode';
    $password = 'V:iCOv/p0:XZnl:I';
    $db     = '3335699_nitrode';
    
    //Create the connection and select the database
    $db = new mysqli($host, $username, $password, $db);
    
    // Check the connection
    if($db->connect_error){
        die("Connexion error: " . $db->connect_error);
    }
    
    //Get the image from the database
    $res = $db->query("SELECT asset FROM asset WHERE id = {$_GET['id']}");
    
    if($res->num_rows > 0){
        $img = $res->fetch_assoc();
        
        //Render the image
        header("Content-type: txt"); 
        echo $img['asset']; 
    }else{
        echo 'Not A Valid Asset';
    }
}
?>