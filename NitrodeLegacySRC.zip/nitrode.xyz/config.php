<?php


define('DB_SERVER', "fdb21.awardspace.net");
define('DB_USERNAME', "3335699_nitrode");
define('DB_PASSWORD', "V:iCOv/p0:XZnl:I");
define('DB_NAME', "3335699_nitrode");
 

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>