<?php
// Initialize the session
session_start();
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">


<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/site/dev.css">
	
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="/studio"><img src="/stuff/Image/nitrode-studio.png" width="40" height="40" class="navbar-brandimg d-inline-block mr-2" alt="Nitrode" style="width:auto"> Nitrode Studio</a>
 </div>
</nav>
				<div class="main-content">
                                <h1>Nitrode Studio</h1>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/notuser.php';?>
                                                                <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/loggedin.php';?>
                                                                <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/developinventory.php';?>
                                                                	<div class="card border-primary mb-3" id="recentlyOpenedPlaces">
					<h4 style="margin:0 0 2px">Recently Opened Place Files</h4>
					<p class="muted" style="margin:0;">Well You Did Not Open Any Place Files Yet</p>
                                       </div>
<br><br>
   <center> <a href="/studio/manual" class="btn btn-primary">View Studio Instructions</a> <a href="/develop/" class="btn btn-outline-info btn">Retun To Develop Page (May Not Work Correctly In Studios Built In Internet Explorer)</a> </center>

