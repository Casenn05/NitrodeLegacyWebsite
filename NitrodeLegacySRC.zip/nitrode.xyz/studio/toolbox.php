<?php
// Initialize the session
session_start();
?>
                <title>Toolbox</title>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">


<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/site/dev.css">
	
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>
</p>
<div class="form-group">
                    <label for="exampleSelect1" class="form-label mt-4">Asset Type</label>
                    <select class="form-select" id="exampleSelect1">
                      <option>Models</option>
                      <option>Decals</option>
                      <option>Audio</option>
                      <option>My Models</option>
                      <option>My Decals</option>
                                            <option>My Audio</option>
                    </select>
                  </div>
<form class="d-flex">
                      <input class="form-control me-sm-2" type="text" placeholder="Search">
                      <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
                    </form>
                    <center>
<div class="card border-primary mb-3" style="max-width: 10rem;">
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/toolboxinventory.php';
		?> 
</div>
</center>