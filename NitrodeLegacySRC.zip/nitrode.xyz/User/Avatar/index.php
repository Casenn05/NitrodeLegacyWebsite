<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Avatar   </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
<script src="/stuff/Js/jquery.min.js"></script>
    <script src="/stuff/Js/bootstrap.bundle.min.js"></script>
    <script src="/stuff/Js/prism.js" data-manual></script>
    <script src="/stuff/Js/custom.js"></script>
			</style>
	</head>
  
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';
		?>
                
                 <?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/infoupdate.php'; ?>
  <?php
            $id=69420;
            $user="";$about="";$aeae="";$onn="";$kkz="";
            if(!isset($_GET['id'])){
                if(isset($_SESSION['id'])){$id=$_SESSION['id'];}else{
                    header('Location: 404.php');
                }
            }else{$id=$_GET['id'];}

            $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
            if ($polaczenie->connect_errno!=0)
            {
            }
            else
            {
                if ($rezultat = @$polaczenie->query(
                sprintf("SELECT * FROM users WHERE id='%s'",
                mysqli_real_escape_string($polaczenie,$id))))
                {
                        
                    $ilu_userow = $rezultat->num_rows;
                    if($ilu_userow>0)
                    {
                        $wiersz = $rezultat->fetch_assoc();
                        
                        //	$_SESSION['zalogowany'] = true;
                        $username = $wiersz['username'];
                        $joindate = $wiersz['created_at'];
                                                $charapp = $wiersz['charapp'];
                                                $publicban = $wiersz['publicban'];
                                                                                                $ranktag = $wiersz['ranktag'];
                            $aeae = date("F jS Y", strtotime($joindate));
                        $about = $wiersz['blurb'];
                                                $rank = $wiersz['rank'];
                                                                                                $userfriends = $wiersz['userfriends'];
                                                                                                $status = $wiersz['status'];


                                                $TK = $wiersz['TK'];
                      
                        $rezultat->free_result();  
                        
                    } else {
                        //header('Location: 404.php');
                      
         die();
                    }
                    
                 }
            
                $polaczenie->close();
            }
	/*if(isset($_SESSION['id']) && !($id == $_SESSION['id'])){
		$conn = new mysqli($host, $db_user, $db_password);
		$conn->select_db($db_name);
		$sql = "UPDATE `users` SET `views` = '".($kkz+1)."' WHERE `users`.`id` = ".$id.";";
		$result = $conn->query($sql);
		$conn->close();
	}*/
	
	
        ?>
        				<div class="main-content">
        <div class="home-header"><div class="app container nav-content">
                                <div class="col" style="max-width: 58rem">


        
<div class="row">
<div class="col-md-4">
                     <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/avatar.php';
		?>  
  <center><button type="button" class="btn btn-outline-primary">Regen Avatar <i class="fa-solid fa-arrows-rotate"></i></button>
</center>
 </div></div>


<div class="col-md-4 mt-4">
<center><h8>Body Colors</h8></center>
<div class="ColorChooserFrame mx-auto" style="height:240px;width:194px;text-align:center;">
				<div style="position: relative; margin: 11px 4px; height: 1%;">
					<div style="position: absolute; left: 72px; top: 0px; cursor: pointer">
						<div class="ColorChooserRegion" data-body-part="Head" style="background-color:#FFC9C9;height:44px;width:44px;"></div>
					</div>
					<div style="position: absolute; left: 0px; top: 52px; cursor: pointer">
						<div class="ColorChooserRegion" data-body-part="Right Arm" style="background-color:#FFC9C9;height:88px;width:40px;">
		

       </div>
					</div>
					<div style="position: absolute; left: 48px; top: 52px; cursor: pointer">
						<div class="ColorChooserRegion" data-body-part="Torso" style="background-color:#6B327C;height:88px;width:88px;"></div>
					</div>
					<div style="position: absolute; left: 144px; top: 52px; cursor: pointer">
						<div class="ColorChooserRegion" data-body-part="Left Arm" style="background-color:#FFC9C9;height:88px;width:40px;"></div>
					</div>
					<div style="position: absolute; left: 48px; top: 146px; cursor: pointer">
						<div class="ColorChooserRegion" data-body-part="Left Leg" style="background-color:#287F47;height:88px;width:40px;"></div>
					</div>
					<div style="position: absolute; left: 96px; top: 146px; cursor: pointer">
						<div class="ColorChooserRegion" data-body-part="Right Leg" style="background-color:#287F47;height:88px;width:40px;"></div>
</div></div></div></div>
   <p class="mb-0 mt-1"></p></div>  <div class="col-md-8 divider-bottom">

 <ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" data-bs-toggle="tab" href="#hats">Hats</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#faces">Faces</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#heads">Heads</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#package">Packages</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#tshirts">T-Shirts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#shirts">Shirts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#pants">Pants</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#gears">Gears</a>
  </div>
  <div class="items row">
				  	<div class="col-sm-3 col-6 mb-3 px-2">
  </li>
  </div>


                           
          <p></p>
          

      </div>
    </div>
  </div>
</div>

 
</div>
    </p>
</body>
</html>
        
       
			</div>
		</div>
	</div>
 <div></div>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>

	</footer>
        <?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>
		

       
			</div>
		</div>
	</div>
 <div></div>
 
	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>
 
	</footer>
        <?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>
		
 