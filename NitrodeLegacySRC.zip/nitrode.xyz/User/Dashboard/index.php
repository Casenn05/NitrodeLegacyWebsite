<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Dashboard </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}

</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>
	</head>
  
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';
		?>
				<div class="main-content">
                              


</div>
          <p></p>
          

 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
    </style>
</head>
<body>
<div class="home-header"></div>
<div class="app container nav-content" data-user-id="<?php echo($_SESSION["id"]); ?>">
<h2><a>Hello, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</a></h2>
<div class="row">
<div class="col-lg-3 col-md-4 p-0 divider-right">
		<div class="p-3 text-center">
<div class="card border-primary mb-3" style="max-width: 30rem;">
                 <?php include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/infoupdate.php'; ?>
  <?php
            $id=69420;
            $user="";$about="";$aeae="";$onn="";$kkz="";
            if(!isset($_GET['id'])){
                if(isset($_SESSION['id'])){$id=$_SESSION['id'];}else{
                    header('Location: 404.php');
                }
            }else{$id=$_GET['id'];}

            $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
            if ($polaczenie->connect_errno!=0)
            {
            }
            else
            {
                if ($rezultat = @$polaczenie->query(
                sprintf("SELECT * FROM users WHERE id='%s'",
                mysqli_real_escape_string($polaczenie,$id))))
                {
                        
                    $ilu_userow = $rezultat->num_rows;
                    if($ilu_userow>0)
                    {
                        $wiersz = $rezultat->fetch_assoc();
                        
                        //	$_SESSION['zalogowany'] = true;
                        $username = $wiersz['username'];
                        $joindate = $wiersz['created_at'];
                                                $charapp = $wiersz['charapp'];
                                                $publicban = $wiersz['publicban'];
                                                                                                $ranktag = $wiersz['ranktag'];
                            $aeae = date("F jS Y", strtotime($joindate));
                        $about = $wiersz['blurb'];
                                                $rank = $wiersz['rank'];
                                                                                                $userfriends = $wiersz['userfriends'];
                                                                                                $status = $wiersz['status'];


                                                $TK = $wiersz['TK'];
                      
                        $rezultat->free_result();  
                        
                    } else {
                        //header('Location: 404.php');
                      
         die();
                    }
                    
                 }
            
                $polaczenie->close();
            }
	/*if(isset($_SESSION['id']) && !($id == $_SESSION['id'])){
		$conn = new mysqli($host, $db_user, $db_password);
		$conn->select_db($db_name);
		$sql = "UPDATE `users` SET `views` = '".($kkz+1)."' WHERE `users`.`id` = ".$id.";";
		$result = $conn->query($sql);
		$conn->close();
	}*/
	
	
        ?>
        

<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/avatar.php';
		?>   
               <?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/rendertest.php';
		?>   
               
 

  </div>
</div></div>
					</div>
				</div>
		 	</div>
		</div>
	</div>

						</div>
					</div>
				</div>
			</div>
		</div>
		
				  </div>

</div>


   
    


</div>

    </p>
</body>
</html>
        
       
			</div>
		</div>
	</div>
        <br>

</center>
 <footer><?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?></footer><?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/ads/ad1.php';
		?>  
        