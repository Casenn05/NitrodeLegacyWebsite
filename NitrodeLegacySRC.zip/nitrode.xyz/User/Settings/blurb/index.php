<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Settings   </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
   <script src="/stuff/Js/jquery.min.js"></script>
    <script src="/stuff/Js/bootstrap.bundle.min.js"></script>
    <script src="/stuff/Js/prism.js" data-manual></script>
    <script src="/stuff/Js/custom.js"></script>
			</style>
	</head>
  
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';
		?>
				<div class="main-content">
                            <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="/User/Settings/">Basic</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="">Blurb</a>
    </li>
     <li class="nav-item">
      <a class="nav-link" href="/User/Settings/discord">Discord</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/User/Settings/themes">Themes</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/User/Settings/experimental">Experimental</a>
    </li>
  </ul>
  <br>
  <?php
           
                                 include_once $_SERVER['DOCUMENT_ROOT'].'/site/configfiles/db.php';              
                              $sql = "SELECT id FROM users WHERE username = ?";
                           if($_SERVER['REQUEST_METHOD'] == 'POST')
                          ;
            $param_blurb = trim($_POST["blurb"]);
                        if(mysqli_stmt_execute($stmt));
                            mysqli_stmt_store_result($stmt);
                                                $blurb = trim($_POST["blurb"]); 
                                                              mysqli_stmt_close($stmt)  ;    
           

     

    mysqli_close($link);
;?>
        
  <h1>Blurb</h1>
  <center>
  <div class="card border-primary mb-3" style="max-width: 50rem;">
  <div class="card-body">
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <div class="form-group">
                    <label for="exampleTextarea" class="form-label mt-4">Blurb</label>
                    <textarea class="form-control" id=blurb" rows="3"><?php echo $wiersz['blurb']; ?></textarea>
                  </div>
<div class="d-grid gap-2">

  <button type="submit" class="btn btn-lg btn-primary" type="button">Set Blurb</button></center>
</div>


    </p>
</body>
</html>
        
       
			</div>
		</div>
	</div>
 <div></div></div>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>

	</footer>
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>