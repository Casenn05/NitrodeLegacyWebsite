<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Beta Mode   </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
   <script src="/stuff/Js/jquery.min.js"></script>
    <script src="/stuff/Js/bootstrap.bundle.min.js"></script>
    <script src="/stuff/Js/prism.js" data-manual></script>
    <script src="/stuff/Js/custom.js"></script>
			</style>
	</head>
  

<br><br>
<center><div class="card border-primary mb-3" style="max-width: 30rem;">
  <div class="card-header">Warning</div>
  <div class="card-body">
    <h4 class="card-title">You Are Now Enabling Beta Mode</h4>
    <img src="/stuff/Image/Icons/warning.png" alt="error  width=" 80"="" height="90">
    <p class="card-text">You Will Gain Access To New Features Some Features May Not Work Properly Are You Sure You Want To Continue</p>
     <a href="" class="btn btn-outline-info btn-lg mt-3 mr-2">Continue</a>
          <a href="/User/Settings/experimental/" class="btn btn-outline-danger btn-lg mt-3 mr-2">Go Back</a>
  </div>
 </div></center>
 
  <div></div>

	<script src="/stuff/Js/vendor.js?id=8b3429e686afebc7c135"></script>
		<script src="/stuff/Js/app.js?id=7b645c19cf6e275a061c"></script>
		<script>
			window.Nitrode.LoadedEnd = true;
			window.Nitrode.idk = false;
			window.Nitrode.why = null;
					</script>