                                                                                        <link rel="stylesheet" href="https://blog.nitrode.xyz/sitestuff/css/style.css">
<link rel="icon" href="https://blog.nitrode.xyz/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Nitrode | Site Offline</title>
<head>
  <meta charset="UTF-8">
  <meta name="description" content="The Site Is Currently Getting Rewritten">
  <meta name="keywords" content="Nitrode,Roblox,Old Roblox">
  <meta name="author" content="casenn05">
</head>
        		<div class="main-content">
                        <br>
                        <center>
<div class="card border-primary mb-3" style="max-width: 50rem;">
  <div class="card-body">
    <h4 class="card-title">Nitrode Is Offline</h4>
    <p class="card-text">The Site Is Currently Getting Rewritten Visit The <a href="https://blog.nitrode.xyz">Blog</a> For Updates
</p>
<img src="https://blog.nitrode.xyz/sitestuff/textures/NitrodeLogo.png" width="250" height="250" alt="logo">

  </div>
</div></center>

</div>
<hr>
<center><b>Nitrode 2022©</b></center>
<center><p><small>We Are In No Way Affliated With Roblox </small></p></center>