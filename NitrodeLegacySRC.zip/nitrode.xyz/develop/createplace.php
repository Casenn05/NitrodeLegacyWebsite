<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /login");
    exit;
}
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Create Place   </title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
											<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
   <script src="/stuff/Js/jquery.min.js"></script>
    <script src="/stuff/Js/bootstrap.bundle.min.js"></script>
    <script src="/stuff/Js/prism.js" data-manual></script>
    <script src="/stuff/Js/custom.js"></script
			</style>
	</head>
  
<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';
		?>
				<div class="main-content">


                              <center>
                              <div class="card border-primary mb-3" style="max-width: 40rem;">
  <div class="card-body">

    <p><h1>Place Creation</h1><br> <label for="nameplace" class="col-sm-2 col-form-label">Place Name</label>
      <input type="nameplace" class="form-control" id="nameplace" aria-describedby="nameplace" placeholder="Enter Name Of Place">
<br>
                    <label for="descplace" class="form-label mt-4">Place Description</label>
                    <textarea class="form-control" id="descplace" rows="3"></textarea> <br>
                    <label for="players">Player Amount:</label>
  <select name="players" "id="players">
    
       <option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
                                                                                                                														<option value="20" selected="selected">20</option>
  </select>

						<label for="Version">Client Version:</label>
						<select name="Version" "id="Version">

                                                                                                                														<option value="2008">2008</option>
														<option value="2011" selected="selected">2011</option>
                                                                                                                                                                                                                                														<option value="2013">2013</option>

                                                                                                                														<option value="2016">2016</option>
													</select>
                                                                                                       
                                                                                                        
                                                                                                        
						<label for="privacy">Privacy:</label>
						<select name="privacy" "id="privacy">
							<option value="public">Public</option>
							<option value="hidden">Hidden</option>
						</select><br><br>
                                                 
                                                                                                        <label for="bodytype">Body Type (2016 Only):</label>
						<select name="body" "id="bodytype">


														<option value="R6" selected="selected">R6</option>

                                                                                                                														<option value="R15">R15 (Experimental)</option>
													</select>
						</p>
                                                <label for="PlayerCount">Gear types:</label>
                                                <div style="max-width: 32rem;" class="row ml-4">
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_melee" name="gear_melee">
								<label class="form-check-label" for="gear_melee">Melee</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_powerup" name="gear_powerup">
								<label class="form-check-label" for="gear_powerup">Power ups</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_ranged" name="gear_ranged">
								<label class="form-check-label" for="gear_ranged">Ranged</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_navigation" name="gear_navigation">
								<label class="form-check-label" for="gear_navigation">Navigation</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_explosive" name="gear_explosive">
								<label class="form-check-label" for="gear_explosive">Explosives</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_musical" name="gear_musical">
								<label class="form-check-label" for="gear_musical">Musical</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_social" name="gear_social">
								<label class="form-check-label" for="gear_social">Social</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_transport" name="gear_transport">
								<label class="form-check-label" for="gear_transport">Transport</label>
							</div>
						</div>
												<div class="col-sm-4 mb-1">
							<div class="form-check">
								<input type="checkbox" class="form-check-input" id="gear_building" name="gear_building">
								<label class="form-check-label" for="gear_building">Building</label>
							</div>
						</div>
											</div>
                                                                                        <div class="form-group" style="max-width: 26rem;">
						<label for="ChatType">Chat Type (Not Supported With 2008):</label>
						<select name="ChatType" class="form-control form-control-sm" id="ChatType">
							<option>Classic</option>
							<option>Bubble</option>
							<option selected="selected">Both</option>
						</select>
					</div>
                                        <p>Click on the "Choose File" button to upload a Place File or Leave Blank For A Baseplate:</p>

  <input id="file" type="file" name="fileToUpload" accept=".rbxl,.rbxlx/"> 


</form><div class="d-grid gap-2">
  <button class="btn btn-lg btn-success" type="button">Create Place <i class="fa-solid fa-plus"></i></button>

					</div>
					</div>


  </div>

</center>
  </div>
</div>
<!DOCTYPE html>
<html>
<body>
<center>

</div>
  </center>
</form>

</body>
</html>


</div>
          <p></p>
          

 
</div>

    </p>
</body>
</html>
        
       
			</div>
		</div>
	</div>
 <div></div>
</div>
	<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>