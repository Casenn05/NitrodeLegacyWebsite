<?php
// Initialize the session
session_start();
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Audio Asset</title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>

<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?>

				<div class="main-content">
                               <h1>Nitrode Audio</h1>                                
                                <center>
                                <div class="card border-primary mb-3" style="max-width: 50rem;">

  <div class="card-body">
    <h4 class="card-title">Barney - If Your Happy And You Know It</h4>
<small>Uploaded By: <b>casenn05</b></small></p>
<audio src="http://api.nitrode.xyz/asset/audio/notfromroblox/id/2" controls></audio>
<p><b> Asset Link:</b>
 <code style="word-wrap: break-word;white-space: pre-line;">http://api.nitrode.xyz/asset/audio/notfromroblox/id/2</code>
</p><small>Copy The Asset Link And Paste It Into Studio</small>
  </div></center>
                                </div>
          <p></p>
          

 
</div> 

    </p>
</body>
</html>
        
       
			</div>
		</div>
	</div>
 <div></div>

	<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>