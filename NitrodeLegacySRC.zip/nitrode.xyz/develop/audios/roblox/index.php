<?php
// Initialize the session
session_start();
?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">

<link rel="manifest" href="/site.webmanifest">

<html lang="en">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="HBt9WdQhfjkbKd0kTmiEz4YpedoEwX1RA5GDmW2p">
		<title>	Nitrode | Audios</title>
		<link rel="shortcut icon" type="image/png" href="/img/rsz_busy.png">
		<link rel="stylesheet" href="/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
												<link rel="stylesheet" href="/stuff/css/bootstrap.css">

<script src="https://kit.fontawesome.com/54c9d73cd7.js" crossorigin="anonymous"></script>

						<style>
h1:not(.forum-header),h2:not(.forum-header),h3:not(.forum-header),h4:not(.forum-header),h5:not(.forum-header),h6:not(.forum-header){font-family:"proxima-nova","Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}*,html,body,button,input,textarea,select{font-family:"Source Sans Pro", "Helvetica Neue", Roboto, "Chiron Sans HK WS", "Microsoft JhengHei", "PingFang HK", "MingLiU", Arial, sans-serif;}
</style>		<!-- this must load before anything else -->
<script src="/stuff/Js/manifest.js"></script>
<script src="/stuff/Js/settings.js"></script>
			</style>

<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbar.php';?>
<?php if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) include_once $_SERVER['DOCUMENT_ROOT'].'/site/navbarlog.php';?>

				<div class="main-content">
                               <h1>casenn05,s Roblox Audio Archive</h1>                                
                                <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Party Palace</h4>
<small>Original Uploader: <b>mharkshark</b></small></p>
    <a href="/develop/audios/roblox/view/1008995020/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">M.U.L.E</h4>
<small>Original Uploader: <b>clockwork</b></small></p>
    <a href="/develop/audios/roblox/view/1077604/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Cursed Abbey</h4>
<small>Original Uploader: <b>clockwork</b></small></p>
    <a href="/develop/audios/roblox/view/1372257/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Fire Emblem - Super Smash Bros Melee</h4>
<small>Original Uploader: <b>clockwork</b></small></p>
    <a href="/develop/audios/roblox/view/1372259/" class="btn btn-default">View Audio</a>

  </div></center>
                                   
                                   <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">The mean (er) kitty song</h4>
<small>Original Uploader: <b>trickybrother</b></small></p>
    <a href="/develop/audios/roblox/view/2050065073/" class="btn btn-default">View Audio</a>

  </div></center>
     <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Barney I Love You</h4>
<small>Original Uploader: <b>AmtrakCardinal</b></small></p>
    <a href="/develop/audios/roblox/view/206609064/" class="btn btn-default">View Audio</a>

  </div></center>
   <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Decisions</h4>
<small>Original Uploader: <b>CrazyBlox</b></small></p>
    <a href="/develop/audios/roblox/view/265420675/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Zero Project - Gothic</h4>
<small>Original Uploader: <b>RobloSam</b></small></p>
    <a href="/develop/audios/roblox/view/27697743/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Destructoid</h4>
<small>Original Uploader: <b>CrazyBlox</b></small></p>
    <a href="/develop/audios/roblox/view/265700635/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Barney Theme Song</h4>
<small>Original Uploader: <b>casenn05</b></small></p>
    <a href="/develop/audios/roblox/view/7048800367/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Barney Clean Up Song</h4>
<small>Original Uploader: <b>casenn05</b></small></p>
    <a href="/develop/audios/roblox/view/7153997631/" class="btn btn-default">View Audio</a>

  </div></center>
  <center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Mule2</h4>
<small>Original Uploader: <b>Unknown</b></small></p>
    <a href="/develop/audios/roblox/view/9044/" class="btn btn-default">View Audio</a>

  </div></center><center>
                                <div class="card border-primary mb-3" style="max-width: 20rem;">

  <div class="card-body">
    <h4 class="card-title">Windows 98 commercial music</h4>
<small>Original Uploader: <b>Inquirix</b></small></p>
    <a href="/develop/audios/roblox/view/959314639/" class="btn btn-default">View Audio</a>

  </div></center>
                                
                                </div>
          <p></p>
          

 
</div> 

    </p>
</body>
</html>
        
       
			</div>
		</div>
	</div>
 <div></div>

	<?php
			include_once $_SERVER['DOCUMENT_ROOT'].'/site/footer.php';
		?>